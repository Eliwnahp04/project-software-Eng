<?php
$servername = "localhost";
$username = "root";
$password = "password";
$database = "VougeVenture";