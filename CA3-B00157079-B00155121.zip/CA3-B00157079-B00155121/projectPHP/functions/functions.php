
function selectfromuser(){

        try {
            $conn = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
        
            // Select all data from User table
            $stmt = $conn->query("SELECT * FROM User");
            $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
            // Display user data
            echo "<pre>";
            print_r($users);
            echo "<pre>";

    }
}