<?php
class Purchase {
    private $purchase_id;
    private $item_id;
    private $quantity;
    private $customer_id;
    private $status;
    private $pickup_time;

    const DSN = "mysql:host=localhost;dbname=vougeventure";
    const USERNAME = "root";
    const PASSWORD = "password";

  public function __construct($purchaseID, $cusID, $cartID, $empID, $paymentdetails) {
        $this->purchaseID = $purchaseID;
        $this->cusID = $cusID;
        $this->cartID = $cartID;
        $this->empID = $empID;
        $this->paymentdetails = $paymentdetails;
    }

    // Setters
    public function setPurchaseId($purchase_id) {
        $this->purchase_id = $purchase_id;
    }

    public function setItemId($item_id) {
        $this->item_id = $item_id;
    }

    public function setQuantity($quantity) {
        $this->quantity = $quantity;
    }

    public function setCustomerId($customer_id) {
        $this->customer_id = $customer_id;
    }

    public function setStatus($status) {
        $this->status = $status;
    }

    public function setPickupTime($pickup_time) {
        $this->pickup_time = $pickup_time;
    }

    // Getters
    public function getPurchaseId() {
        return $this->purchase_id;
    }

    public function getItemId() {
        return $this->item_id;
    }

    public function getQuantity() {
        return $this->quantity;
    }

    public function getCustomerId() {
        return $this->customer_id;
    }

    public function getStatus() {
        return $this->status;
    }

    public function getPickupTime() {
        return $this->pickup_time;
    }

    public function insertPurchase() {
        try {
            // Connect to the database
            $pdo = new PDO(self::DSN, self::USERNAME, self::PASSWORD);

            // Prepare the SQL query
            $stmt = $pdo->prepare("INSERT INTO purchase (purchaseID, cusID, cartID, empID, paymentdetails) VALUES (:purchaseID, :cusID, :cartID, :empID, :paymentdetails)");

            // Bind parameter values
            $stmt->bindParam(':purchaseID', $this->purchaseID, PDO::PARAM_INT);
            $stmt->bindParam(':cusID', $this->cusID, PDO::PARAM_INT);
            $stmt->bindParam(':cartID', $this->cartID, PDO::PARAM_INT);
            $stmt->bindParam(':empID', $this->empID, PDO::PARAM_INT);
            $stmt->bindParam(':paymentdetails', $this->paymentdetails, PDO::PARAM_STR);

            // Execute the query
            $stmt->execute(); 
            echo "Data inserted successfully.";
        } catch (PDOException $e) {
            // Handle database connection errors
            echo "Connection failed: " . $e->getMessage();
        }
    }

    public function displayPurchaseDetails() {
        try {
            // Connect to the database
            $pdo = new PDO(self::DSN, self::USERNAME, self::PASSWORD);
    
            // Prepare the SQL query
            $stmt = $pdo->prepare("SELECT * FROM purchase WHERE purchaseID = :purchaseID");
            $stmt->bindParam(':purchaseID', $this->purchaseID, PDO::PARAM_INT);
    
            // Execute the query
            $stmt->execute(); 
    
            // Fetch the result
            $purchase = $stmt->fetch(PDO::FETCH_ASSOC);
    
            // Display the purchase details
            echo "<h2>Purchase Details</h2>";
            echo "<p>Purchase ID: " . $purchase['purchaseID'] . "</p>";
    
            // Check if cusID key exists before accessing it
            if (isset($purchase['cusID'])) {
                echo "<p>Customer ID: " . $purchase['cusID'] . "</p>";
            } else {
                echo "<p>Customer ID: N/A</p>";
            }
    
            // Check if cartID key exists before accessing it
            if (isset($purchase['cartID'])) {
                echo "<p>Cart ID: " . $purchase['cartID'] . "</p>";
            } else {
                echo "<p>Cart ID: N/A</p>";
            }
    
            // Check if empID key exists before accessing it
            if (isset($purchase['empID'])) {
                echo "<p>Employee ID: " . $purchase['empID'] . "</p>";
            } else {
                echo "<p>Employee ID: N/A</p>";
            }
    
            // Check if paymentdetails key exists before accessing it
            if (isset($purchase['paymentdetails'])) {
                echo "<p>Payment Details: " . $purchase['paymentdetails'] . "</p>";
            } else {
                echo "<p>Payment Details: N/A</p>";
            }
    
        } catch (PDOException $e) {
            // Handle database connection errors
            echo "Connection failed: " . $e->getMessage();
        }
    }
    
}
    


// Usage


