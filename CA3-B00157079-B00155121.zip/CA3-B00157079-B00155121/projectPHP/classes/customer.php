<?php

class customer{

private $customerid;

function __construct($customerid){
    $this->setCustomerId($customerid);
}

public function setCustomerId($customerid) {
    $this->customerid = $customerid;
}
public function getCustomerID() {
    return $this->customerid;
}

function displaycustomer($customer){
    echo "customer ID: " . $this->getCustomerID() . "<br>";
}
}