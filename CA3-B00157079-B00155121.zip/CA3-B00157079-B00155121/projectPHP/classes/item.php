<?php
class Item {
    private $itemID;
    private $itemname;
    private $itemdescription;
    private $itemprice;
    private $itemQuantity;

    const DSN = "mysql:host=localhost;dbname=vougeventure";
    const USERNAME = "root";
    const PASSWORD = "password";



    public function insertPurchase()  {
        try {
            // Connect to the database
            $pdo = new PDO(self::DSN, self::USERNAME, self::PASSWORD);

            // Prepare the SQL query
            $stmt = $pdo->prepare("INSERT INTO item (itemID, itemname, itemdescription, itemprice, itemQuantity) VALUES (:itemID, :itemname, :itemdescription, :itemprice, :itemQuantity)");

            // Bind parameter values
            $stmt->bindParam(':itemID', $this->itemID, PDO::PARAM_INT);
            $stmt->bindParam(':itemname', $this->itemname, PDO::PARAM_STR);
            $stmt->bindParam(':itemdescription', $this->itemdescription, PDO::PARAM_STR);
            $stmt->bindParam(':itemprice', $this->itemprice, PDO::PARAM_STR);
            $stmt->bindParam(':itemQuantity', $this->itemQuantity, PDO::PARAM_INT);

            // Execute the query
            $stmt->execute(); 
            echo "Data inserted successfully.";
        } catch (PDOException $e) {
            // Handle database connection errors
            echo "Connection failed: " . $e->getMessage();
        }
    }


    public function displayItemDetails() {
        try {
            // Connect to the database
            $pdo = new PDO(self::DSN, self::USERNAME, self::PASSWORD);
    
            // Prepare the SQL query
            $stmt = $pdo->prepare("SELECT * FROM item WHERE itemID = :itemID");
            $stmt->bindParam(':itemID', $this->itemID, PDO::PARAM_INT);
    
            // Execute the query
            $stmt->execute(); 
    
            // Fetch the result
            $item = $stmt->fetch(PDO::FETCH_ASSOC);
    
            // Display the item details
            echo "<h2>Item Details</h2>";
    
            // Check if itemID key exists before accessing it
            if (isset($item['itemId'])) {
                echo "<p>Item ID: " . $item['itemId'] . "</p>";
            } else {
                echo "<p>Item ID: N/A</p>";
            }
    
            // Check and display other item details similarly
            // Check if itemname key exists before accessing it
            if (isset($item['itemName'])) {
                echo "<p>Item Name: " . $item['itemName'] . "</p>";
            } else {
                echo "<p>Item Name: N/A</p>";
            }
    
            // Check if itemdescription key exists before accessing it
            if (isset($item['itemDescription'])) {
                echo "<p>Item Description: " . $item['itemDescription'] . "</p>";
            } else {
                echo "<p>Item Description: N/A</p>";
            }
    
            // Check if itemprice key exists before accessing it
            if (isset($item['itemPrice'])) {
                echo "<p>Item Price: " . $item['itemPrice'] . "</p>";
            } else {
                echo "<p>Item Price: N/A</p>";
            }
    
            // Check if itemQuantity key exists before accessing it
            if (isset($item['itemQuantity'])) {
                echo "<p>Item Quantity: " . $item['itemQuantity'] . "</p>";
            } else {
                echo "<p>Item Quantity: N/A</p>";
            }
    
        } catch (PDOException $e) {
            // Handle database connection errors
            echo "Connection failed: " . $e->getMessage();
        }
    }
    

    function __construct($itemID, $itemname, $itemdescription, $itemprice, $itemQuantity) {
        $this->setItemID($itemID);
        $this->setItemName($itemname);
        $this->setItemDescription($itemdescription);
        $this->setItemPrice($itemprice);
        $this->setItemQuantity($itemQuantity);
    }

    public function displayItem() {
        echo "Item ID: " . $this->getItemID() . "<br>";
        echo "Item Name: " . $this->getItemName() . "<br>";
        echo "Item Description: " . $this->getItemDescription() . "<br>";
        echo "Item Price: $" . $this->getItemPrice() . "<br>";
        echo "Item Quantity: " . $this->getItemQuantity() . "<br>";
    }

    public function getItemID() {
        return $this->itemID;
    }

    public function getItemName() {
        return $this->itemname;
    }

    public function getItemDescription() {
        return $this->itemdescription;
    }

    public function getItemPrice() {
        return $this->itemprice;
    }

    public function getItemQuantity() {
        return $this->itemQuantity;
    }

    public function setItemID($itemID) {
        $this->itemID = $itemID;
    }

    public function setItemName($itemname) {
        $this->itemname = $itemname;
    }

    public function setItemDescription($itemdescription) {
        $this->itemdescription = $itemdescription;
    }

    public function setItemPrice($itemprice) {
        $this->itemprice = $itemprice;
    }

    public function setItemQuantity($itemQuantity) {
        $this->itemQuantity = $itemQuantity;
    }
}

